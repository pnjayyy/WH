<?php

// check if the user is already logged in , redirect to the dashboard page
session_start();

 if(isset($_SESSION['email']))
 {
    header('Location: dashboard.php');
 }

 
 ?>
 <!DOCTYPE html>
 <html lang="en">
 <head>
     <title>JWR Warehouse</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
     <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600&display=swap" rel="stylesheet">
     <style>
         * {
             margin: 0;
             padding: 0;
             box-sizing: border-box;
         }
 
         body {
             background-color: rgb(215, 212, 238);
             font-family: 'Poppins', sans-serif;
             display: flex;
             justify-content: center;
             align-items: center;
             height: 100vh;
         }
 
         .container {
             position: relative;
             width: 400px;
             background-color: rgba(48, 40, 40, 0.93);
             padding: 50px 35px;
             backdrop-filter: blur(10px);
             border-radius: 10px;
             border: 2px solid rgba(255, 255, 255, 0.1);
             box-shadow: 0 0 40px rgba(8, 7, 16, 0.6);
         }
 
         h1 {
             font-size: 32px;
             font-weight: 600;
             color: #fff;
             text-align: center;
             margin-bottom: 30px;
         }
 
         .alert {
             display: flex;
             justify-content: space-between;
             padding: 10px;
             margin-bottom: 20px;
             background: #ffcccc;
             color: #cc0000;
             border-radius: 5px;
             font-size: 14px;
         }
 
         .alert.success {
             background: #d4edda;
             color: #155724;
         }
 
         .alert .close-alert {
             cursor: pointer;
         }
 
         .form-group {
             position: relative;
             margin-top: 20px;
         }
 
         label {
             position: absolute;
             top: 14px;  /* ปรับให้อยู่ตำแหน่งเดิม */
             left: 15px;
             font-size: 18px; /* ขนาดตัวอักษรใหญ่ขึ้น */
             color: #e5e5e5;
             transition: 0.3s;
             font-weight: 500; /* ให้ตัวอักษรหนาขึ้น */
             pointer-events: none; /* ทำให้ label ไม่ขวางการคลิก input */
         }
 
         input {
             width: 100%;
             height: 50px;
             background-color: rgba(255, 255, 255, 0.07);
             border-radius: 3px;
             padding: 0 10px;
             font-size: 18px; /* ขนาดตัวอักษรใหญ่ขึ้นใน input */
             color: #fff;
             padding-top: 12px;
             border: none;
             transition: 0.3s;
         }
 
         input:focus {
             outline: none;
             background-color: rgba(255, 255, 255, 0.1);
         }
 
         input:focus + label,
         input:not(:placeholder-shown) + label {
             top: -15px; /* ปรับให้ label ย้ายขึ้นเล็กน้อย */
             font-size: 16px; /* ขนาดตัวอักษรเล็กลงเมื่อกรอกข้อมูล */
             color: rgb(219, 40, 16); /* เปลี่ยนสีเมื่อกรอกข้อมูล */
             transform: translateY(-5px); /* ให้ label เด้งขึ้นนิดหน่อย */
         }
 
         button {
             width: 100%;
             height: 50px;
             margin-top: 30px;
             background-color: #573b8a;
             color: #fff;
             font-size: 16px;
             font-weight: bold;
             border: none;
             border-radius: 5px;
             cursor: pointer;
             transition: 0.3s;
         }
 
         button:hover {
             background-color:rgb(49, 230, 79);
         }
 
         button:active {
             background-color: #4b2876;
         }
 
         .register-link {
             margin-top: 20px;
             color: #e5e5e5;
             text-align: center;
         }
 
         .register-link a {
             color:rgb(218, 41, 35);
             text-decoration: none;
         }
 
         .register-link a:hover {
             text-decoration: underline;
         }
 
         /* Mobile responsiveness */
         @media screen and (max-width: 600px) {
             .container {
                 width: 90%;
                 padding: 30px 20px;
             }
 
             h1 {
                 font-size: 26px;
             }
         }
     </style>
 </head>
 <body>
     <div class="container">
         <?php
         if (isset($_SESSION['error'])) {
             echo '<div class="alert error">
                     <p>' . $_SESSION['error'] . '</p>
                     <span class="close-alert">&times;</span>
                   </div>';
             unset($_SESSION['error']);
         }
         if (isset($_SESSION['success'])) {
             echo '<div class="alert success">
                     <p>' . $_SESSION['success'] . '</p>
                     <span class="close-alert">&times;</span>
                   </div>';
             unset($_SESSION['success']);
         }
         ?>
 
         <h1><i class="fas fa-box-open"></i> Warehouse Management System</h1>
 
         <form method="POST" action="login-script.php">
             <div class="form-group">
                 <input type="email" name="email" id="email" placeholder=" " required>
                 <label for="email">Email</label>
             </div>
 
             <div class="form-group">
                 <input type="password" name="password" id="password" placeholder=" " required>
                 <label for="password">Password</label>
             </div>
 
             <button type="submit" name="login">Login</button>
         </form>
 
         <div class="register-link">
             Don't have an account? <a href="register.php">Register</a>
         </div>
     </div>
 
      <script>
          document.addEventListener('DOMContentLoaded', function() {
              const closeButtons = document.querySelectorAll('.close-alert');
              closeButtons.forEach(button => {
                  button.addEventListener('click', function() {
                      this.parentElement.remove();
                  });
              });
          });
      </script>
  </body>
  </html>
 
